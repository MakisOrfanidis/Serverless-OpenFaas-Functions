import com.openfaas.function.Current;
import com.openfaas.function.Internal;
import com.openfaas.function.WeatherApiCall;
import org.junit.Test;
import org.junit.jupiter.api.Assertions;

public class HandlerTest {
    @Test
    public void testGetCurrentWeatherInfoFromIP() throws Internal {
        Current currentWeatherInfo = WeatherApiCall.getCurrentWeatherInfo();
        Assertions.assertNotNull(currentWeatherInfo);
    }
}