package com.openfaas.function;

import org.apache.http.HttpEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpRequestBase;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.util.EntityUtils;

import javax.ws.rs.BadRequestException;
import javax.ws.rs.InternalServerErrorException;
import java.io.IOException;

public class ApiCall {

    //Μέθοδος για URL(αίτημα)    Abstract κλάση  Reference variable τύπου HttpRequestBase
    public static String callApi(HttpRequestBase request) throws IOException {    //Checked Exception για Input-Output operations
        if(request == null) throw new RuntimeException("Δεν γίνεται το request να είναι null"); //Unchecked Exception, δεν χρειάζεται δήλωση πάνω

        //φτιάχνουμε reference variable της abstract κλάσης HttpClientBuilder
        HttpClientBuilder builder = HttpClientBuilder.create(); //δημιουργούμε τον builder για CloseableHttpClient instances
        //φτιάχνουμε reference variable της abstract κλάσης CloseableHttpClient
        CloseableHttpClient client = builder.build(); //φτιάχνουμε τον http client
        try (
                //φτιάχνουμε reference variable του interface CloseableHttpResponse
                CloseableHttpResponse response = client.execute(request)) { //εκτελείται το Http request και λαμβάνουμε το response object
            //Έλεγχος αν υπάρχει σφάλμα σχετικά με τον client παίρνωντας το status code του Http response
            if(response.getStatusLine().getStatusCode() == 400) {
                throw new BadRequestException(EntityUtils.toString(response.getEntity())); //επιστρέφει την απάντηση του μηνύματος ως String
            }
            //Έλεγχος αν υπάρχει σφάλμα σχετικά με τον server παίρνωντας το status code του Http response
            if(response.getStatusLine().getStatusCode() == 500) {
                throw new InternalServerErrorException(EntityUtils.toString(response.getEntity())); //επιστρέφει την απάντηση του μηνύματος ως String
            }
            //Απάντηση-Δεδομένα που επιστρέφονται από το Web Service
            HttpEntity entity = response.getEntity();
            //Έλεγχος για null
            if (entity != null) {
                return EntityUtils.toString(entity); //επιστρέφει το περιεχόμενο του body του HTTP response ως String, αν όλα καλά
            }
        }
        throw new RuntimeException("Λάθος στο κάλεσμα του api");
    }
}
