package com.openfaas.function;

import com.openfaas.model.IHandler;
import com.openfaas.model.IRequest;
import com.openfaas.model.IResponse;
import com.openfaas.model.Response;

import java.util.Date;


public class Handler implements IHandler {

    public IResponse Handle(IRequest req) {
        IResponse res = new Response();

        try {
            Current curweather = WeatherApiCall.getCurrentWeatherInfo();
            Date dtDate = new Date(curweather.getCurrent().getDt() * 1000);

            res.setBody("\nlat=" + curweather.getLat() + "\nlon=" + curweather.getLon() + "\ntimezone="
                    + curweather.getTimezone() + "\n\n" + dtDate + curweather.getCurrent());
        } catch (Exception e) {
            e.printStackTrace();
            res.setBody(e.toString());

        }

        return res;
    }
}
