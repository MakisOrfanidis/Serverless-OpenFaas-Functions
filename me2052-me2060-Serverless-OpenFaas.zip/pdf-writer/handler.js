'use strict'
const PDFDocument = require('pdfkit')
const axios = require('axios');


module.exports = async (event, context) => {
    const payment = 100;
    let pdf = await createDocument(payment)
    return context
        .status(200)
        .headers({
            "Content-type": "application/pdf"
        })
        .succeed(pdf)
}


function createDocument() {
    return new Promise(async resolve => {
        const doc = new PDFDocument({
            size: "LEGAL",
            title: "Pdf Function",
            author: "Makis"
        });

        const buffers = [];
        doc.on("data", buffers.push.bind(buffers));
        doc.on("end", () => {
            resolve(Buffer.concat(buffers));
        });

        let imageUrl = "https://incognito.socialcomputing.eu/wp-content/uploads/2019/02/unipi.jpg";
        let response = await axios.request(
            {
                method: "GET",
                url: imageUrl,
                responseEncoding: "binary"
            });
        let responseData = response.data;
        let imgBinary = Buffer.from(responseData, "binary");

        // Μετατροπή σε base64 string.
        let imgBase64 = imgBinary.toString("base64");
        let img = Buffer.from(imgBase64, "base64");

        doc.image(img, {
            fit: [100, 100],
            align: 'center',
            valign: 'top'
        });

        let Names = 'Efthymios Orfanidis & Thomas Tsopelas';
        doc.text(`Names: ${Names}`);
        doc.end();
    });
}